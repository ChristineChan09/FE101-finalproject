$(document).ready(function(){
	$("#gametitle").mouseover(function(){
		this.stop();
	$("#gametitle").mouseout(function(){
		this.start();
		});
	});
	$("#page").click(function(){
		$("#arrows").fadeIn(2000);
	});
	$("#page").hover(function(){
		$("#arrows").fadeOut(2000);
	});
	$("body").click(function(){
		$(".modal-wrapper").hide();
	});
	$("#question").hover(function(){
		$(".modal-wrapper").fadeIn(10000);
	});
	$(".modal-wrapper").fadeOut(9000);
			
});	



	




